###                    process_pipline.R                   ###
### ====================================================== ###
# This R script is a pipline to analyze drug pair synergy


#######################################
### Set working directory
#######################################
# User needs to change setwd() to their own directory that contains this script 
setwd("/home2/s418336/project/drugCombination/DIGREsyn-software")

suppressMessages(library(argparse))


#######################################
### 0. Parse comandline argument
#######################################

### get arguments
parser <- ArgumentParser(description = "This pipline is to analyze drug pair syngergy using DIGRE model.")
parser$add_argument("geneExp", type = "character", help = "Passing in the gene expression data file name.")
parser$add_argument("doseRes", type = "character", help = "Passing in the dose response data file name.")
parser$add_argument("-p", "--pathway", type = "integer", default = 1, help =  "The pathway information to use: 1 for KEGG pathway information, 2 for constructed lymphoma gene network(partial corelation) information, 3 for constructed lymphoma gene network(marginal corelation) information. Default is 1.")
parser$add_argument("-f", "--fold", type = "double", default = 0.6, help = "The gene expression fold change cut off to use, should be decimal between zero and one. Default is 0.6.")

pip_args <- parser$parse_args()
geneExp <- pip_args$geneExp
doseRes <- pip_args$doseRes
pathway <- pip_args$pathway
fold <- pip_args$fold


### concatenate input and output file path
cur.path <- getwd()
doseRes.path <- paste(cur.path, "/data/", doseRes, sep = "")
geneExp.path <- paste(cur.path, "/data/", geneExp, sep = "")
res.path <- paste(cur.path, "/report/", unlist(strsplit(geneExp, ".", fixed = TRUE))[1], ".scoreRank.csv", sep = "")





#######################################
### 1. Load library and functions
#######################################
cat("Loading packages and functions......\n")
suppressMessages(library(preprocessCore))
suppressMessages(library(org.Hs.eg.db))
suppressMessages(library(KEGGgraph))

source("code/doseRes.R")
source("code/profileGeneExp.R")
source("code/scoring.R")



#######################################
### 2. Read data
#######################################

# read dose response data
doseRes <- readDoseRes.csv(doseRes.path)

# prepare drug treated gene expression data
geneExpDiff <- profileGeneExp(geneExp.path)

# load pathway information



########################################
### 3. Scoring by DIGRE model
########################################
cat("\n\nStart scoring all compound pairs by DIGRE model......\n")
cat("=================================================\n")
cat("* Fold change cut off used: ", fold, "(default = 0.6)\n", sep = "")
if (pathway == 1) {
      cat("* Pathway information used: KEGG pathway information\n")
      load("data/pathInfo.Rdata")
      res <- scoring(geneExpDiff = geneExpDiff$geneExp.max, doseRes = doseRes, CGP.mat = CGP.mat, GP.mat = GP.mat, fold = fold)
}
if (pathway == 2) {
      cat("* Pathway information used: Gene network information(partial corelation)\n")
      load("data/gLassoGeneNet.Rdata")
      res <- scoring(geneExpDiff = geneExpDiff$geneExp.max, doseRes = doseRes, CGP.mat = mCGP.mat, GP.mat = mGP.mat, fold = fold)
}
if (pathway == 3) {
      cat("* Pathway information used: Gene network information(marginal corelation)\n")
      load("data/marGeneNet.Rdata")
      res <- scoring(geneExpDiff = geneExpDiff$geneExp.max, doseRes = doseRes, CGP.mat = mCGP.mat, GP.mat = mGP.mat, fold = fold)
}
res.score <- res$scoreRank
write.csv(res.score, res.path, row.names = FALSE)
cat("\n\nScoring done, result file generated in report folder.\n")



